'use client';

import React, { useState, useEffect } from 'react';
import Script from 'next/script';

interface InterstitialAdProps {
  adUnitId: string;
  onAdClosed?: () => void;
}

export default function InterstitialAd({ adUnitId, onAdClosed }: InterstitialAdProps) {
  const [adLoaded, setAdLoaded] = useState(false);
  const [adShown, setAdShown] = useState(false);

  useEffect(() => {
    // Create a div for the interstitial ad
    const adContainer = document.createElement('div');
    adContainer.id = 'interstitial-ad-container';
    adContainer.style.position = 'fixed';
    adContainer.style.top = '0';
    adContainer.style.left = '0';
    adContainer.style.width = '100%';
    adContainer.style.height = '100%';
    adContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    adContainer.style.zIndex = '9999';
    adContainer.style.display = 'flex';
    adContainer.style.justifyContent = 'center';
    adContainer.style.alignItems = 'center';
    adContainer.style.flexDirection = 'column';
    
    // Add close button
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Close Ad';
    closeButton.style.position = 'absolute';
    closeButton.style.top = '10px';
    closeButton.style.right = '10px';
    closeButton.style.padding = '8px 16px';
    closeButton.style.backgroundColor = '#f44336';
    closeButton.style.color = 'white';
    closeButton.style.border = 'none';
    closeButton.style.borderRadius = '4px';
    closeButton.style.cursor = 'pointer';
    closeButton.style.zIndex = '10000';
    
    closeButton.onclick = () => {
      document.body.removeChild(adContainer);
      setAdShown(true);
      if (onAdClosed) {
        onAdClosed();
      }
    };
    
    // Create ad element
    const adElement = document.createElement('ins');
    adElement.className = 'adsbygoogle';
    adElement.style.display = 'block';
    adElement.style.width = '300px';
    adElement.style.height = '250px';
    adElement.setAttribute('data-ad-client', 'ca-pub-4078051717971122');
    adElement.setAttribute('data-ad-slot', adUnitId);
    
    // Add countdown text
    const countdownText = document.createElement('div');
    countdownText.style.color = 'white';
    countdownText.style.marginTop = '20px';
    countdownText.style.fontSize = '16px';
    countdownText.textContent = 'You can close this ad in 5 seconds...';
    
    // Append elements
    adContainer.appendChild(closeButton);
    adContainer.appendChild(adElement);
    adContainer.appendChild(countdownText);
    
    // Function to show the ad
    window.showInterstitialAd = () => {
      if (adShown) return; // Only show once
      
      document.body.appendChild(adContainer);
      
      // Push the ad
      try {
        (window as any).adsbygoogle = (window as any).adsbygoogle || [];
        (window as any).adsbygoogle.push({});
      } catch (error) {
        console.error('AdSense error:', error);
      }
      
      // Countdown timer
      let countdown = 5;
      const timer = setInterval(() => {
        countdown--;
        if (countdown <= 0) {
          clearInterval(timer);
          countdownText.textContent = 'You can close this ad now';
          closeButton.style.backgroundColor = '#4CAF50';
        } else {
          countdownText.textContent = `You can close this ad in ${countdown} seconds...`;
        }
      }, 1000);
      
      // Auto-close after 15 seconds if user doesn't close it
      setTimeout(() => {
        if (document.body.contains(adContainer)) {
          document.body.removeChild(adContainer);
          setAdShown(true);
          if (onAdClosed) {
            onAdClosed();
          }
        }
      }, 15000);
    };
    
    setAdLoaded(true);
    
    // Cleanup
    return () => {
      if (document.body.contains(adContainer)) {
        document.body.removeChild(adContainer);
      }
      delete window.showInterstitialAd;
    };
  }, [adUnitId, onAdClosed, adShown]);

  return null;
}

// Add showInterstitialAd to Window interface
declare global {
  interface Window {
    showInterstitialAd?: () => void;
    adsbygoogle: any[];
  }
}
