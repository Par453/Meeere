import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Asura Downloader</h3>
            <p className="text-gray-300">
              Your ultimate tool for 4K/8K video downloading, enhancement, and more!
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition duration-300">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/downloader" className="text-gray-300 hover:text-white transition duration-300">
                  Video Downloader
                </Link>
              </li>
              <li>
                <Link href="/video-enhancer" className="text-gray-300 hover:text-white transition duration-300">
                  Video Enhancer
                </Link>
              </li>
              <li>
                <Link href="/photo-enhancer" className="text-gray-300 hover:text-white transition duration-300">
                  Photo Enhancer
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition duration-300">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <p className="text-gray-300 mb-2">
              Have questions or feedback? Reach out to us on Telegram!
            </p>
            <div className="flex items-center">
              <div className="bg-blue-500 text-white p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <Link href="/contact" className="text-blue-300 hover:text-white transition duration-300">
                @ABOUT8ASURA
              </Link>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-700 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Asura Downloader. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
