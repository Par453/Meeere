
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <nav className="bg-gradient-to-r from-purple-800 to-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">
              Asura Downloader
            </Link>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-6">
            <Link href="/" className="hover:text-blue-200 transition duration-300">
              Home
            </Link>
            <Link href="/downloader" className="hover:text-blue-200 transition duration-300">
              Video Downloader
            </Link>
            <Link href="/video-enhancer" className="hover:text-blue-200 transition duration-300">
              Video Enhancer
            </Link>
            <Link href="/photo-enhancer" className="hover:text-blue-200 transition duration-300">
              Photo Enhancer
            </Link>
            <Link href="/contact" className="hover:text-blue-200 transition duration-300">
              Contact
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button 
              className="mobile-menu-button outline-none" 
              onClick={toggleMobileMenu} 
              aria-label="Toggle mobile menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`mobile-menu md:hidden ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
          <div className="flex flex-col space-y-3 py-4">
            <Link href="/" className="block px-4 py-2 hover:bg-blue-700 rounded transition duration-300" onClick={toggleMobileMenu}>
              Home
            </Link>
            <Link href="/downloader" className="block px-4 py-2 hover:bg-blue-700 rounded transition duration-300" onClick={toggleMobileMenu}>
              Video Downloader
            </Link>
            <Link href="/video-enhancer" className="block px-4 py-2 hover:bg-blue-700 rounded transition duration-300" onClick={toggleMobileMenu}>
              Video Enhancer
            </Link>
            <Link href="/photo-enhancer" className="block px-4 py-2 hover:bg-blue-700 rounded transition duration-300" onClick={toggleMobileMenu}>
              Photo Enhancer
            </Link>
            <Link href="/contact" className="block px-4 py-2 hover:bg-blue-700 rounded transition duration-300" onClick={toggleMobileMenu}>
              Contact
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

