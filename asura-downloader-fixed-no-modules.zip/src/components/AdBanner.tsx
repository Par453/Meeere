'use client';

import React from 'react';
import Script from 'next/script';

interface AdBannerProps {
  adUnitId: string;
  style?: React.CSSProperties;
}

export default function AdBanner({ adUnitId, style }: AdBannerProps) {
  React.useEffect(() => {
    // Initialize ads when component mounts
    try {
      (window as any).adsbygoogle = (window as any).adsbygoogle || [];
      (window as any).adsbygoogle.push({});
    } catch (error) {
      console.error('AdSense error:', error);
    }
  }, []);

  return (
    <>
      <div className="ad-container my-4" style={style}>
        <ins
          className="adsbygoogle"
          style={{ display: 'block' }}
          data-ad-client="ca-pub-4078051717971122"
          data-ad-slot={adUnitId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        ></ins>
      </div>
    </>
  );
}
