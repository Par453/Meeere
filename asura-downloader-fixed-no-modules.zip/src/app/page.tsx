'use client';

import React from 'react';
import Link from 'next/link';
import { useState } from 'react';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('downloader');

  return (
    <main className="flex min-h-screen flex-col items-center p-6 md:p-12">
      <div className="w-full max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">Welcome to Asura Downloader</h1>
        <p className="text-lg text-center mb-12">Your ultimate tool for 4K/8K video downloading, enhancement, and more!</p>
        
        <div className="bg-white rounded-lg shadow-lg p-6 mb-12">
          <h2 className="text-2xl font-bold mb-4 text-center">Guide for New Users</h2>
          <p className="mb-6">Asura Downloader allows you to perform the following tasks:</p>
          
          <div className="mb-8">
            <div className="flex border-b">
              <button 
                className={`px-4 py-2 ${activeTab === 'downloader' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
                onClick={() => setActiveTab('downloader')}
              >
                Video Downloader
              </button>
              <button 
                className={`px-4 py-2 ${activeTab === 'videoenhancer' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
                onClick={() => setActiveTab('videoenhancer')}
              >
                Video Enhancer
              </button>
              <button 
                className={`px-4 py-2 ${activeTab === 'photoenhancer' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
                onClick={() => setActiveTab('photoenhancer')}
              >
                Photo Enhancer
              </button>
            </div>
            
            <div className="p-4">
              {activeTab === 'downloader' && (
                <div>
                  <h3 className="text-xl font-semibold mb-3">How to Use the Video Downloader:</h3>
                  <ol className="list-decimal pl-6 space-y-3">
                    <li><strong>Enter Video URL</strong> - Paste the URL of the video you want to download.</li>
                    <li><strong>Select Quality</strong> - Choose your preferred quality from the dropdown (720p, 1080p, 4K, or 8K).</li>
                    <li><strong>Click Download Button</strong> - Click the "Download Video" button to start the process.</li>
                    <li><strong>Download Video</strong> - Once processing is complete, click the download link to save the video to your device.</li>
                  </ol>
                  <div className="mt-4 p-3 bg-blue-50 text-blue-700 border border-blue-200 rounded">
                    <strong>Example URL:</strong> https://www.pexels.com/video/video-of-forest-1448735/
                  </div>
                </div>
              )}
              
              {activeTab === 'videoenhancer' && (
                <div>
                  <h3 className="text-xl font-semibold mb-3">How to Use the Video Enhancer:</h3>
                  <ol className="list-decimal pl-6 space-y-3">
                    <li><strong>Upload Video</strong> - Choose the video file from your device to enhance.</li>
                    <li><strong>Adjust Parameters</strong> - Use the sliders to adjust brightness, contrast, saturation, and sharpness.</li>
                    <li><strong>Select Resolution</strong> - Choose your preferred output resolution.</li>
                    <li><strong>Click Enhance Button</strong> - Click the "Enhance Video" button to start the process.</li>
                    <li><strong>Download Enhanced Video</strong> - Once processing is complete, click the download link to save the enhanced video to your device.</li>
                  </ol>
                  <div className="mt-4 p-3 bg-purple-50 text-purple-700 border border-purple-200 rounded">
                    <strong>Tip:</strong> For best results, use shorter video clips (under 30 seconds).
                  </div>
                </div>
              )}
              
              {activeTab === 'photoenhancer' && (
                <div>
                  <h3 className="text-xl font-semibold mb-3">How to Use the Photo Enhancer:</h3>
                  <ol className="list-decimal pl-6 space-y-3">
                    <li><strong>Upload Photo</strong> - Choose the image file from your device to enhance.</li>
                    <li><strong>View Preview</strong> - See a preview of the uploaded image.</li>
                    <li><strong>Adjust Parameters</strong> - Use the sliders to adjust brightness, contrast, saturation, and sharpness.</li>
                    <li><strong>Select Resolution</strong> - Choose your preferred output resolution.</li>
                    <li><strong>Click Enhance Button</strong> - Click the "Enhance Photo" button to start the process.</li>
                    <li><strong>Download Enhanced Photo</strong> - Once processing is complete, click the download link to save the enhanced photo to your device.</li>
                  </ol>
                  <div className="mt-4 p-3 bg-green-50 text-green-700 border border-green-200 rounded">
                    <strong>Tip:</strong> Adjust brightness and contrast before increasing sharpness.
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <Link href="/downloader" className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300">
              Start Video Downloader
            </Link>
            <Link href="/video-enhancer" className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition duration-300">
              Start Video Enhancer
            </Link>
            <Link href="/photo-enhancer" className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition duration-300">
              Start Photo Enhancer
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-4 text-center">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Is this service completely free?</h3>
              <p>Yes, Asura Downloader is completely free to use. We sustain the service through advertisements.</p>
            </div>
            <div>
              <h3 className="font-semibold">Which platforms can videos be downloaded from?</h3>
              <p>Our downloader can fetch videos from most popular social media platforms, but please note that the terms of service of some platforms may not permit video downloading.</p>
            </div>
            <div>
              <h3 className="font-semibold">Can I download videos in 8K resolution?</h3>
              <p>Yes, if the original video is available in 8K, you can download it in 8K resolution.</p>
            </div>
            <div>
              <h3 className="font-semibold">How long does video or photo enhancement take?</h3>
              <p>Processing time depends on the file size, selected parameters, and server load. Smaller videos or photos usually process within a few minutes.</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

