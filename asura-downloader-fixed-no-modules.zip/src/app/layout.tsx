import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Script from 'next/script';
import './globals.css';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import AdBanner from '@/components/AdBanner'; // Import AdBanner

const inter = Inter({ subsets: ['latin'] });

// Improved Metadata for SEO
export const metadata: Metadata = {
  metadataBase: new URL('https://lydyfuxy.manus.space'), // Replace with actual deployed URL
  title: {
    default: 'Asura Downloader - Free 4K/8K Video Downloader & Enhancer',
    template: '%s | Asura Downloader',
  },
  description: 'Download videos in 4K/8K HD from various platforms. Enhance your videos and photos with powerful AI tools. Free, fast, and easy to use.',
  keywords: ['video downloader', '4K downloader', '8K downloader', 'HD video downloader', 'video enhancer', 'photo enhancer', 'AI video enhancement', 'AI photo enhancement', 'free downloader', 'Asura Downloader'],
  openGraph: {
    title: 'Asura Downloader - Free 4K/8K Video Downloader & Enhancer',
    description: 'Download videos in 4K/8K HD, enhance videos and photos with AI. Free and easy!',
    url: 'https://lydyfuxy.manus.space', // Replace with actual deployed URL
    siteName: 'Asura Downloader',
    // Add a representative image URL here if available, e.g., '/og-image.png'
    // images: [
    //   {
    //     url: '/og-image.png', // Must be an absolute URL or start with / 
    //     width: 1200,
    //     height: 630,
    //     alt: 'Asura Downloader Banner',
    //   },
    // ],
    locale: 'en_US',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  // Add Twitter card metadata if needed
  // twitter: {
  //   card: 'summary_large_image',
  //   title: 'Asura Downloader - Free 4K/8K Video Downloader & Enhancer',
  //   description: 'Download videos in 4K/8K HD, enhance videos and photos with AI. Free and easy!',
  //   // images: ['/og-image.png'], // Must be an absolute URL or start with /
  // },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const bannerAdUnitId = "ca-app-pub-4078051717971122/1745570745"; // User's Banner Ad Unit ID

  return (
    <html lang="en">
      <head>
        {/* Google AdSense Script */}
        <Script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4078051717971122"
          crossOrigin="anonymous"
          strategy="afterInteractive"
        />
      </head>
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen">
          <Navbar />
          <main className="flex-grow">{children}</main> {/* Removed container here, added to individual pages */}
          {/* Banner Ad near Footer */}
          <AdBanner adUnitId={bannerAdUnitId} />
          <Footer />
        </div>
      </body>
    </html>
  );
}

