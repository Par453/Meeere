
// Modified content for /home/ubuntu/asura-downloader/src/app/downloader/page.tsx

// Moved 'use client' to the top
'use client';

import type { Metadata } from 'next';
import React, { useState } from 'react';
// import InterstitialAd from '@/components/InterstitialAd'; // Commented out ad component import

// Removed metadata export as it's not allowed in client components
// export const metadata: Metadata = {
//   title: 'Video Downloader | Asura Downloader',
//   description: 'Download videos in 4K/8K HD quality from various social media platforms. Free, fast, and easy to use with no watermarks.',
//   keywords: ['video downloader', 'HD video download', '4K download', '8K download', 'social media video downloader', 'free video downloader'],
// };

// Define interface for API response data
interface ApiResponse {
  success?: boolean;
  downloadUrl?: string;
  message?: string;
  error?: string;
  details?: string;
}

export default function DownloaderPage() {
  const [url, setUrl] = useState('');
  const [format, setFormat] = useState('720'); // Default format
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [downloadLink, setDownloadLink] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  // const [showAd, setShowAd] = useState(false); // Commented out ad state

  // const rewardedAdUnitId = "ca-app-pub-4078051717971122/5496888157"; // Commented out ad unit ID

  const startDownloadProcess = async () => {
    setIsLoading(true);
    setError(null);
    setDownloadLink(null);
    setMessage('Starting download...');

    try {
      const response = await fetch('/api/download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url, format }),
      });

      // Explicitly type the response data
      const data = await response.json() as ApiResponse;

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Download failed');
      }

      if (data.downloadUrl) {
        setDownloadLink(data.downloadUrl);
      }
      setMessage(data.message || 'Download successful!');
      setUrl(''); // Clear input after successful download

    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
      setMessage(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Modified handleDownloadClick to bypass ad logic
  const handleDownloadClick = () => {
    setError(null);
    setDownloadLink(null);
    setMessage(null);
    // Directly start download process, bypassing ad logic
    console.warn('Ad logic bypassed for fixing.');
    startDownloadProcess();
  };

  // const handleAdClosed = () => { // Commented out ad closed handler
  //   setShowAd(false);
  //   startDownloadProcess(); // Proceed with download after ad is closed
  // };

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Interstitial Ad Component (does not render visually here) */}
      {/* <InterstitialAd adUnitId={rewardedAdUnitId} onAdClosed={handleAdClosed} /> */} {/* Commented out ad component usage */}

      <h1 className="text-3xl font-bold mb-6 text-center">Video Downloader</h1>
      <p className="mb-4 text-center text-gray-600">Enter the URL of the video you want to download:</p>

      <div className="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <div className="mb-4 relative group">
          <label htmlFor="videoUrl" className="block text-sm font-medium text-gray-700 mb-1">Video URL</label>
          <input
            id="videoUrl"
            type="text"
            placeholder="https://..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading} // Removed showAd condition
            title="Paste the full web address (URL) of the video you want to download here."
          />
        </div>

        <div className="mb-6 relative group">
          <label htmlFor="formatSelect" className="block text-sm font-medium text-gray-700 mb-1">Select Quality</label>
          <select
            id="formatSelect"
            value={format}
            onChange={(e) => setFormat(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading} // Removed showAd condition
            title="Choose the desired quality for the downloaded video (e.g., 720p, 1080p, 4K, 8K)."
          >
            <option value="720">720p (HD)</option>
            <option value="1080">1080p (Full HD)</option>
            <option value="4k">4K (Ultra HD)</option>
            <option value="8k">8K (Ultra HD)</option>
          </select>
        </div>

        <button
          onClick={handleDownloadClick} // Use the modified handler
          className={`w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`} // Removed showAd condition
          disabled={isLoading} // Removed showAd condition
          title="Click to start the video download process."
        >
          {isLoading ? 'Downloading...' : 'Download Video'} {/* Removed showAd condition */}
        </button>

        {isLoading && (
          <div className="mt-4 text-center text-gray-600">
            Downloading, please wait... This might take a while depending on the video size.
          </div>
        )}

        {/* {showAd && !isLoading && ( // Commented out ad loading message
           <div className="mt-4 text-center text-gray-600">
             Please watch the ad to start your download.
           </div>
        )} */}

        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded">
            <strong>Error:</strong> {error}
          </div>
        )}

        {message && !isLoading && (
          <div className="mt-4 p-3 bg-green-100 text-green-700 border border-green-300 rounded">
            {message}
          </div>
        )}

        {downloadLink && (
          <div className="mt-6 text-center">
            <a
              href={downloadLink}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded transition duration-300"
              title="Click here to save your downloaded video."
            >
              Click Here to Download Your Video
            </a>
          </div>
        )}
      </div>

      {/* SEO-friendly content section */}
      <div className="max-w-3xl mx-auto mt-12 bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Download High-Quality Videos with Asura Downloader</h2>
        <p className="mb-4">
          Asura Downloader is a powerful, free online tool that lets you download videos from various social media platforms in high quality, including HD, Full HD, 4K, and even 8K resolution.
        </p>

        <h3 className="text-xl font-semibold mt-6 mb-3">Why Choose Asura Downloader?</h3>
        <ul className="list-disc pl-6 space-y-2 mb-6">
          <li><strong>High-Quality Downloads:</strong> Download videos in resolutions up to 8K Ultra HD.</li>
          <li><strong>Multiple Platform Support:</strong> Works with videos from most popular social media platforms.</li>
          <li><strong>Fast and Free:</strong> No registration required, completely free to use.</li>
          <li><strong>No Watermarks:</strong> Downloaded videos are clean without any watermarks.</li>
          <li><strong>Easy to Use:</strong> Simple interface that anyone can use without technical knowledge.</li>
        </ul>

        <h3 className="text-xl font-semibold mt-6 mb-3">How to Download Videos</h3>
        <ol className="list-decimal pl-6 space-y-2 mb-6">
          <li>Copy the URL of the video you want to download.</li>
          <li>Paste the URL in the input field above.</li>
          <li>Select your preferred quality (720p, 1080p, 4K, or 8K).</li>
          <li>Click the "Download Video" button.</li>
          <li>After processing, click the download link to save your video.</li>
        </ol>

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mt-6">
          <h4 className="font-semibold text-blue-800 mb-2">Important Note:</h4>
          <p className="text-blue-700">
            Please respect copyright laws and terms of service of the platforms you download from. Asura Downloader is designed for downloading videos that you have permission to download.
          </p>
        </div>
      </div>
    </div>
  );
}

