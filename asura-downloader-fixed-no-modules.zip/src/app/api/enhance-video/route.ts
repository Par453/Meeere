import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { writeFile } from 'fs/promises';

const execPromise = promisify(exec);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'videos');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const brightness = formData.get('brightness') as string || '0';
    const contrast = formData.get('contrast') as string || '1';
    const saturation = formData.get('saturation') as string || '1';
    const sharpness = formData.get('sharpness') as string || '1';
    const resolution = formData.get('resolution') as string || 'original';
    
    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    // Generate unique filename
    const timestamp = Date.now();
    const fileExtension = file.name.split('.').pop();
    const originalFilename = `original_${timestamp}.${fileExtension}`;
    const enhancedFilename = `enhanced_${timestamp}.mp4`;
    
    const originalFilePath = path.join(uploadsDir, originalFilename);
    const enhancedFilePath = path.join(uploadsDir, enhancedFilename);
    
    // Save the uploaded file
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(originalFilePath, buffer);
    
    // Build FFmpeg command for enhancement
    let resolutionOption = '';
    if (resolution !== 'original') {
      switch (resolution) {
        case '720p':
          resolutionOption = '-vf "scale=1280:720"';
          break;
        case '1080p':
          resolutionOption = '-vf "scale=1920:1080"';
          break;
        case '4k':
          resolutionOption = '-vf "scale=3840:2160"';
          break;
        case '8k':
          resolutionOption = '-vf "scale=7680:4320"';
          break;
      }
    }
    
    // Build the FFmpeg command with filters
    let command = `ffmpeg -i "${originalFilePath}" -vf "eq=brightness=${brightness}:contrast=${contrast}:saturation=${saturation},unsharp=5:5:${sharpness}:5:5:0" -c:v libx264 -preset medium -crf 22 -c:a aac -b:a 128k`;
    
    // Add resolution option if specified
    if (resolutionOption) {
      command = `ffmpeg -i "${originalFilePath}" -vf "eq=brightness=${brightness}:contrast=${contrast}:saturation=${saturation},unsharp=5:5:${sharpness}:5:5:0,scale=${resolution}" -c:v libx264 -preset medium -crf 22 -c:a aac -b:a 128k`;
    }
    
    // Complete the command with output file
    command += ` "${enhancedFilePath}"`;
    
    // Execute FFmpeg command
    const { stdout, stderr } = await execPromise(command);
    
    // Check if enhanced file exists
    if (!fs.existsSync(enhancedFilePath)) {
      return NextResponse.json({ 
        error: 'Enhancement failed', 
        details: stderr 
      }, { status: 500 });
    }
    
    // Return the download URL for the enhanced video
    const downloadUrl = `/uploads/videos/${enhancedFilename}`;
    
    return NextResponse.json({ 
      success: true, 
      downloadUrl,
      message: 'Video enhanced successfully',
      details: stdout
    });
    
  } catch (error) {
    console.error('Enhancement error:', error);
    return NextResponse.json({ 
      error: 'Failed to enhance video', 
      details: error instanceof Error ? error.message : String(error) 
    }, { status: 500 });
  }
}
