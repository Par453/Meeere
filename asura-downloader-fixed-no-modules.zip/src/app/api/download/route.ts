// Modified content for /home/ubuntu/asura-downloader/src/app/api/download/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';

const execPromise = promisify(exec);

// Define the expected structure of the request body
interface DownloadRequestBody {
  url: string;
  format?: string; // format is optional, defaults to '720'
}

// Create downloads directory if it doesn't exist
const downloadsDir = path.join(process.cwd(), 'public', 'downloads');
if (!fs.existsSync(downloadsDir)) {
  fs.mkdirSync(downloadsDir, { recursive: true });
}

export async function POST(request: NextRequest) {
  try {
    // Explicitly type the request body
    const body = await request.json() as DownloadRequestBody;
    const { url, format = '720' } = body;

    if (!url) {
      return NextResponse.json({ error: 'URL is required' }, { status: 400 });
    }

    // Generate a unique filename based on timestamp
    const timestamp = Date.now();
    const outputFilename = `video_${timestamp}`;
    const outputPath = path.join(downloadsDir, outputFilename); // Base path without extension

    // Format selection based on requested quality
    let formatOption = '';
    switch (format) {
      case '4k':
        formatOption = '-f "bestvideo[height<=2160]+bestaudio/best[height<=2160]"';
        break;
      case '8k':
        formatOption = '-f "bestvideo[height<=4320]+bestaudio/best[height<=4320]"';
        break;
      case '1080':
        formatOption = '-f "bestvideo[height<=1080]+bestaudio/best[height<=1080]"';
        break;
      case '720':
      default:
        formatOption = '-f "bestvideo[height<=720]+bestaudio/best[height<=720]"';
        break;
    }

    // Construct the expected output filename (assuming mp4 merge)
    const expectedOutputFile = `${outputFilename}.mp4`;
    const expectedOutputPath = path.join(downloadsDir, expectedOutputFile);

    // Execute yt-dlp command, outputting to a path with the expected extension
    // Using --merge-output-format mp4 should ensure the output is .mp4
    const command = `yt-dlp ${formatOption} --merge-output-format mp4 -o "${expectedOutputPath}" "${url}"`;

    console.log(`Executing command: ${command}`); // Log the command
    const { stdout, stderr } = await execPromise(command);
    console.log(`yt-dlp stdout: ${stdout}`);
    console.error(`yt-dlp stderr: ${stderr}`); // Log stderr for debugging

    // Check if the expected file exists after the command execution
    if (!fs.existsSync(expectedOutputPath)) {
        // Optional: Add a small delay and check again in case of filesystem lag
        await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms
        if (!fs.existsSync(expectedOutputPath)) {
            console.error(`Expected output file not found after delay: ${expectedOutputPath}`);
            // Attempt to find *any* file starting with the base name as a fallback
            const files = fs.readdirSync(downloadsDir);
            const fallbackFile = files.find(file => file.startsWith(outputFilename));
            if (fallbackFile) {
                console.warn(`Using fallback file: ${fallbackFile}`);
                const downloadUrl = `/downloads/${fallbackFile}`;
                return NextResponse.json({
                  success: true,
                  downloadUrl,
                  message: 'Video downloaded successfully (fallback filename used)',
                  details: stdout
                });
            } else {
                 console.error('Fallback file search also failed.');
                 return NextResponse.json({ error: 'Download failed: Output file not found.', details: stderr || stdout || 'Unknown error' }, { status: 500 });
            }
        }
    }

    // Return the download URL using the expected filename
    const downloadUrl = `/downloads/${expectedOutputFile}`;

    return NextResponse.json({
      success: true,
      downloadUrl,
      message: 'Video downloaded successfully',
      details: stdout
    });

  } catch (error: any) {
    console.error('Download error caught:', error);
    return NextResponse.json({
      error: 'Failed to download video',
      details: error.stderr || error.stdout || (error instanceof Error ? error.message : String(error))
    }, { status: 500 });
  }
}

