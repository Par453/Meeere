import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { writeFile } from 'fs/promises';

const execPromise = promisify(exec);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'photos');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const brightness = formData.get('brightness') as string || '0';
    const contrast = formData.get('contrast') as string || '0';
    const saturation = formData.get('saturation') as string || '100';
    const sharpness = formData.get('sharpness') as string || '0';
    const resolution = formData.get('resolution') as string || 'original';
    
    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    // Generate unique filename
    const timestamp = Date.now();
    const fileExtension = file.name.split('.').pop();
    const originalFilename = `original_${timestamp}.${fileExtension}`;
    const enhancedFilename = `enhanced_${timestamp}.${fileExtension}`;
    
    const originalFilePath = path.join(uploadsDir, originalFilename);
    const enhancedFilePath = path.join(uploadsDir, enhancedFilename);
    
    // Save the uploaded file
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(originalFilePath, buffer);
    
    // Build ImageMagick command for enhancement
    let resolutionOption = '';
    if (resolution !== 'original') {
      switch (resolution) {
        case 'hd':
          resolutionOption = '-resize 1280x720';
          break;
        case 'fullhd':
          resolutionOption = '-resize 1920x1080';
          break;
        case '4k':
          resolutionOption = '-resize 3840x2160';
          break;
        case '8k':
          resolutionOption = '-resize 7680x4320';
          break;
      }
    }
    
    // Convert brightness from -1 to 1 range to ImageMagick's percentage
    const brightnessPercent = parseFloat(brightness) * 100;
    
    // Convert contrast from 0 to 2 range to ImageMagick's percentage
    const contrastPercent = (parseFloat(contrast) - 1) * 100;
    
    // Convert saturation from 0 to 3 range to ImageMagick's percentage
    const saturationPercent = parseFloat(saturation) * 100;
    
    // Build the ImageMagick command with filters
    let command = `convert "${originalFilePath}" -brightness-contrast ${brightnessPercent}x${contrastPercent} -modulate 100,${saturationPercent},100`;
    
    // Add sharpness if specified
    if (parseFloat(sharpness) > 0) {
      command += ` -sharpen 0x${sharpness}`;
    }
    
    // Add resolution option if specified
    if (resolutionOption) {
      command += ` ${resolutionOption}`;
    }
    
    // Complete the command with output file
    command += ` "${enhancedFilePath}"`;
    
    // Execute ImageMagick command
    const { stdout, stderr } = await execPromise(command);
    
    // Check if enhanced file exists
    if (!fs.existsSync(enhancedFilePath)) {
      return NextResponse.json({ 
        error: 'Enhancement failed', 
        details: stderr 
      }, { status: 500 });
    }
    
    // Return the download URL for the enhanced photo
    const downloadUrl = `/uploads/photos/${enhancedFilename}`;
    
    return NextResponse.json({ 
      success: true, 
      downloadUrl,
      message: 'Photo enhanced successfully',
      details: stdout
    });
    
  } catch (error) {
    console.error('Enhancement error:', error);
    return NextResponse.json({ 
      error: 'Failed to enhance photo', 
      details: error instanceof Error ? error.message : String(error) 
    }, { status: 500 });
  }
}
