
'use client';

import type { Metadata } from 'next';
import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

// Removed metadata export as it's not allowed in client components
// export const metadata: Metadata = {
//   title: 'Contact Us | Asura Downloader',
//   description: 'Contact Asura Downloader support team via Telegram. Find our contact details and QR code. We are here to help with your video downloading and enhancement needs.',
//   keywords: ['contact', 'support', 'Asura Downloader contact', 'Telegram support', 'help', 'feedback'],
// };

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-6 text-center">Contact Us</h1>
      <p className="mb-8 text-center text-gray-600">
        Have questions or feedback? Reach out to us on Telegram!
      </p>

      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 md:mr-8">
            <h2 className="text-xl font-semibold mb-4">Contact Asura</h2>
            <p className="mb-4">
              For support, feature requests, or any questions about our services, please contact us on Telegram.
            </p>
            <div className="flex items-center mb-4">
              <div className="bg-blue-500 text-white p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <span className="font-medium text-lg">@ABOUT8ASURA</span>
            </div>
            <p className="text-sm text-gray-600">
              We typically respond within 24 hours. Please be patient if you don't receive an immediate response.
            </p>
          </div>
          
          <div className="flex flex-col items-center">
            <p className="mb-3 text-center font-medium">Scan QR Code to Contact</p>
            <div className="border-4 border-blue-500 rounded-lg p-1 bg-white">
              <Image 
                src="/images/telegram_qr.jpg" 
                alt="Telegram QR Code for Asura Downloader Support"
                width={200} 
                height={200}
                className="rounded"
              />
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-semibold mb-3">Why Choose Asura Downloader?</h3>
          <ul className="space-y-2">
            <li>✓ High-quality video downloads in up to 8K resolution</li>
            <li>✓ Advanced video and photo enhancement tools</li>
            <li>✓ Fast processing and download speeds</li>
            <li>✓ Completely free to use</li>
            <li>✓ Responsive customer support</li>
          </ul>
        </div>
        
        <div className="mt-8 text-center">
          <Link href="/" className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300">
            Return to Homepage
          </Link>
        </div>
      </div>
    </div>
  );
}

