
// Moved 'use client' to the top
'use client';

import type { Metadata } from 'next';
import React, { useState } from 'react';
// import InterstitialAd from '@/components/InterstitialAd'; // Commented out ad component import
import Image from 'next/image'; // Import Image component

// Removed metadata export as it's not allowed in client components
// export const metadata: Metadata = {
//   title: 'Photo Enhancer | Asura Downloader',
//   description: 'Enhance photo quality using AI. Adjust brightness, contrast, saturation, and sharpness. Upscale images to HD, 4K, or 8K resolution for free online.',
//   keywords: ['photo enhancer', 'AI photo enhancement', 'improve photo quality', 'upscale image', 'image quality enhancer', 'free photo editor', 'online photo enhancer', 'brightness', 'contrast', 'saturation', 'sharpness'],
// };

// Define interface for API response data
interface ApiResponse {
  success?: boolean;
  downloadUrl?: string;
  message?: string;
  error?: string;
  details?: string;
}

export default function PhotoEnhancerPage() {
  const [file, setFile] = useState<File | null>(null);
  const [brightness, setBrightness] = useState(0);
  const [contrast, setContrast] = useState(1);
  const [saturation, setSaturation] = useState(1);
  const [sharpness, setSharpness] = useState(0);
  const [resolution, setResolution] = useState('original');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [downloadLink, setDownloadLink] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  // const [showAd, setShowAd] = useState(false); // Commented out ad state

  // const rewardedAdUnitId = "ca-app-pub-4078051717971122/5496888157"; // Commented out ad unit ID

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const selectedFile = event.target.files[0];
      setFile(selectedFile);
      setDownloadLink(null);
      setMessage(null);
      setError(null);

      // Create preview URL
      const url = URL.createObjectURL(selectedFile);
      setPreviewUrl(url);
    }
  };

  const startEnhancementProcess = async () => {
    if (!file) {
      setError('Please select a photo first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setDownloadLink(null);
    setMessage('Starting enhancement...');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('brightness', String(brightness));
    formData.append('contrast', String(contrast));
    formData.append('saturation', String(saturation));
    formData.append('sharpness', String(sharpness));
    formData.append('resolution', resolution);

    try {
      const response = await fetch('/api/enhance-photo', {
        method: 'POST',
        body: formData,
      });

      // Explicitly type the response data
      const data = await response.json() as ApiResponse;

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Enhancement failed');
      }

      if (data.downloadUrl) {
        setDownloadLink(data.downloadUrl);
      }
      setMessage(data.message || 'Photo enhanced successfully!');

    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during enhancement.');
      setMessage(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Modified handleEnhanceClick to bypass ad logic
  const handleEnhanceClick = () => {
    if (!file) {
      setError('Please select a photo first.');
      return;
    }

    setError(null);
    setDownloadLink(null);
    setMessage(null);

    // Directly start enhancement process, bypassing ad logic
    console.warn('Ad logic bypassed for fixing.');
    startEnhancementProcess();
    /*
    if (window.showInterstitialAd) {
      setShowAd(true);
      window.showInterstitialAd();
    } else {
      // Fallback if ad logic fails or isn't ready
      console.warn('Interstitial ad function not found, proceeding with enhancement.');
      startEnhancementProcess();
    }
    */
  };

  // const handleAdClosed = () => { // Commented out ad closed handler
  //   setShowAd(false);
  //   startEnhancementProcess(); // Proceed with enhancement after ad is closed
  // };

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Interstitial Ad Component (does not render visually here) */}
      {/* <InterstitialAd adUnitId={rewardedAdUnitId} onAdClosed={handleAdClosed} /> */} {/* Commented out ad component usage */}

      <h1 className="text-3xl font-bold mb-6 text-center">Photo Enhancer</h1>
      <p className="mb-8 text-center text-gray-600">Upload your photo and adjust settings to enhance its quality.</p>

      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <div className="mb-6 relative group">
          <label htmlFor="photoUpload" className="block text-sm font-medium text-gray-700 mb-2">Upload Photo</label>
          <input
            id="photoUpload"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100 cursor-pointer"
            disabled={isLoading} // Removed showAd condition
            title="Choose an image file from your device to enhance."
          />
          {file && <p className='text-sm text-gray-500 mt-2'>Selected: {file.name}</p>}
        </div>

        {previewUrl && (
          <div className="mb-6 text-center">
            <p className="text-sm font-medium text-gray-700 mb-2">Preview:</p>
            <Image
              src={previewUrl}
              alt="Preview"
              width={500} // Add width and height for optimization
              height={300}
              style={{ objectFit: 'contain', maxHeight: '20rem', margin: '0 auto' }} // Style for better preview
              className="border rounded"
              title="Preview of the uploaded photo"
            />
          </div>
        )}

        {/* Enhancement Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="relative group">
            <label htmlFor="brightness" className="block text-sm font-medium text-gray-700">Brightness ({brightness.toFixed(2)})</label>
            <input id="brightness" type="range" min="-1" max="1" step="0.05" value={brightness} onChange={(e) => setBrightness(parseFloat(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" disabled={isLoading} title="Adjust the overall brightness of the photo. Negative values darken, positive values brighten." />
          </div>
          <div className="relative group">
            <label htmlFor="contrast" className="block text-sm font-medium text-gray-700">Contrast ({contrast.toFixed(2)})</label>
            <input id="contrast" type="range" min="0" max="2" step="0.05" value={contrast} onChange={(e) => setContrast(parseFloat(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" disabled={isLoading} title="Adjust the difference between the brightest and darkest areas in the photo." />
          </div>
          <div className="relative group">
            <label htmlFor="saturation" className="block text-sm font-medium text-gray-700">Saturation ({saturation.toFixed(2)})</label>
            <input id="saturation" type="range" min="0" max="3" step="0.05" value={saturation} onChange={(e) => setSaturation(parseFloat(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" disabled={isLoading} title="Adjust the intensity of colors in the photo. Higher values make colors more vibrant." />
          </div>
          <div className="relative group">
            <label htmlFor="sharpness" className="block text-sm font-medium text-gray-700">Sharpness ({sharpness.toFixed(2)})</label>
            <input id="sharpness" type="range" min="0" max="5" step="0.1" value={sharpness} onChange={(e) => setSharpness(parseFloat(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" disabled={isLoading} title="Enhance the clarity of edges and details in the photo. Higher values make the photo look sharper." />
          </div>
        </div>

        <div className="mb-6 relative group">
          <label htmlFor="resolutionSelect" className="block text-sm font-medium text-gray-700 mb-1">Target Resolution</label>
          <select
            id="resolutionSelect"
            value={resolution}
            onChange={(e) => setResolution(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
            disabled={isLoading} // Removed showAd condition
            title="Choose the desired output resolution for the enhanced photo."
          >
            <option value="original">Original</option>
            <option value="hd">HD (720p)</option>
            <option value="fullhd">Full HD (1080p)</option>
            <option value="4k">4K (Ultra HD)</option>
            <option value="8k">8K (Ultra HD)</option>
          </select>
        </div>

        <button
          onClick={handleEnhanceClick} // Use the modified handler
          className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded transition duration-300 ${isLoading || !file ? 'opacity-50 cursor-not-allowed' : ''}`} // Removed showAd condition
          disabled={isLoading || !file} // Removed showAd condition
          title="Click to start the photo enhancement process."
        >
          {isLoading ? 'Enhancing...' : 'Enhance Photo'} {/* Removed showAd condition */}
        </button>

        {isLoading && (
          <div className="mt-4 text-center text-gray-600">
            Enhancing photo, please wait...
          </div>
        )}

        {/* {showAd && !isLoading && ( // Commented out ad loading message
           <div className="mt-4 text-center text-gray-600">
             Please watch the ad to start your enhancement.
           </div>
        )} */}

        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded">
            <strong>Error:</strong> {error}
          </div>
        )}

        {message && !isLoading && (
          <div className="mt-4 p-3 bg-green-100 text-green-700 border border-green-300 rounded">
            {message}
          </div>
        )}

        {downloadLink && (
          <div className="mt-6">
            <div className="text-center mb-4">
              <Image
                src={downloadLink}
                alt="Enhanced Photo"
                width={500} // Add width and height for optimization
                height={300}
                style={{ objectFit: 'contain', maxHeight: '20rem', margin: '0 auto' }} // Style for better preview
                className="border rounded"
              />
            </div>
            <div className="text-center">
              <a
                href={downloadLink}
                download
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded transition duration-300"
                title="Click here to save your enhanced photo."
              >
                Download Enhanced Photo
              </a>
            </div>
          </div>
        )}
      </div>

      {/* SEO-friendly content section */}
      <div className="max-w-3xl mx-auto mt-12 bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Enhance Your Photos with AI Power</h2>
        <p className="mb-4">
          Bring your photos to life with Asura Downloader's free online Photo Enhancer. Use AI to automatically improve image quality, or manually adjust brightness, contrast, saturation, and sharpness. You can even upscale your images to HD, Full HD, 4K, or 8K resolution.
        </p>

        <h3 className="text-xl font-semibold mt-6 mb-3">Why Use Our Photo Enhancer?</h3>
        <ul className="list-disc pl-6 space-y-2 mb-6">
          <li><strong>AI Enhancement:</strong> Let our AI intelligently improve your photo's colors, lighting, and details.</li>
          <li><strong>Precise Control:</strong> Manually adjust brightness, contrast, saturation, and sharpness for the perfect look.</li>
          <li><strong>High-Resolution Upscaling:</strong> Increase the resolution of your photos up to 8K without losing quality.</li>
          <li><strong>Free Online Tool:</strong> Enhance your photos directly in your browser, no software installation needed.</li>
          <li><strong>User-Friendly:</strong> Simple sliders and options make photo enhancement easy for everyone.</li>
        </ul>

        <h3 className="text-xl font-semibold mt-6 mb-3">How to Enhance Photos</h3>
        <ol className="list-decimal pl-6 space-y-2 mb-6">
          <li>Upload the photo file you want to enhance.</li>
          <li>Use the sliders to adjust brightness, contrast, saturation, and sharpness.</li>
          <li>Select the desired output resolution (Original, HD, Full HD, 4K, 8K).</li>
          <li>Click the "Enhance Photo" button.</li>
          <li>After processing, preview the enhanced photo and click the download link to save it.</li>
        </ol>

        <div className="bg-green-50 p-4 rounded-lg border border-green-200 mt-6">
          <h4 className="font-semibold text-green-800 mb-2">Enhancement Tips:</h4>
          <p className="text-green-700">
            Start with minor adjustments and preview the changes. Over-enhancing can sometimes lead to unnatural results. For best upscaling results, use a clear source image.
          </p>
        </div>
      </div>
    </div>
  );
}

